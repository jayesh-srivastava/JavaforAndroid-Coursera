package mooc.vandy.java4android.calculator.logic;
/**
   Defines the interface for the operate method which each of the 4 math-operation classes would implement
 */

public interface Operations {
    public String operate(int argumentOne, int argumentTwo);

}
